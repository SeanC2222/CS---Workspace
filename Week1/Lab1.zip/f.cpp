//Function definition
#include <iostream>
#include "f.h"

void f(){

   std::cout << "This was function \"f()\"! " << std::endl;
   return;
}
