//Function Definition
#include <iostream>
#include "g.h"
void g() {
   std::cout << "This was function \"g()\"! " << std::endl;
   return;

}
   
