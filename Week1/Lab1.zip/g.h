#ifndef g_h 
#define g_h 

#include <iostream>
//Function Definition
void g();


#endif
