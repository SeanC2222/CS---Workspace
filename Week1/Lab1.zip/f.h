#ifndef f_h
#define f_h

#include <iostream>

//Function definition
void f();

#endif
